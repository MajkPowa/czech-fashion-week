CFW iconography
24 x 24 grid; 1.65px square-cut strokes; currentColor.
Use individual SVGs or cfw-icons.svg as an SVG symbol sprite.
Icon-only controls require an accessible name; decorative icons should be hidden from assistive technology.
